@extends('layouts.app')

@section('content')
<p>Dashboard</p>
@endsection
